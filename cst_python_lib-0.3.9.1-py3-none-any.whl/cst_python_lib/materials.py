from typing import Union
# ==============================材料========================================
class Materials:
    def __init__(self,modeler):
        self.modeler = modeler;
    def create_new_materials(self,name:str,er:Union[int,float],tand:Union[int,float]):
        """
        Used to create new material

        Args:
            name (str) : name of material\n
            er (Union[int,float]) : dielectric constant of a substance\n
            tand (Union[int,float]) : loss tangent Angle of a substance
        """
        line_break = '\n'#换行
        #新建所需介质材料
        sCommand = ['With Material',
                    '.Reset',
                    '.Name "%s"'%name,
                    '.FrqType "all"',
                    '.Type "Normal"',
                    '.Epsilon %f' %er,
                    '.TanDGiven "True"',
                    '.TanD %f' %tand,
                    '.Create',
                    'End With']
        sCommand = line_break.join(sCommand)
        self.modeler.add_to_history('define material', sCommand)
        #新建所需介质材料结束
    def imp_materials(self,name):
        """
        Used to import existing material

        Args:
            name (str) : name of material
        """
        line_break = '\n'#换行
        if name == "Gold":
            sCommand = [ 'With Material',
                        '.Reset',
                        '.Name "Gold"',
                        '.Folder ""',
                       '.FrqType "static"',
                        '.Type "Normal"',
                        '.SetMaterialUnit "Hz", "mm"',
                        '.Epsilon "1"',
                        '.Mu "1.0"',
                        '.Kappa "4.561e+007"',
                        '.TanD "0.0"',
                        '.TanDFreq "0.0"',
                        '.TanDGiven "False"',
                        '.TanDModel "ConstTanD"',
                        '.KappaM "0"',
                        '.TanDM "0.0"',
                        '.TanDMFreq "0.0"',
                        '.TanDMGiven "False"',
                        '.TanDMModel "ConstTanD"',
                        '.DispModelEps "None"',
                        '.DispModelMu "None"',
                        '.DispersiveFittingSchemeEps "General 1st"',
                        '.DispersiveFittingSchemeMu "General 1st"',
                        '.UseGeneralDispersionEps "False"',
                        '.UseGeneralDispersionMu "False"',
                        '.FrqType "all"',
                        '.Type "Lossy metal"',
                        '.MaterialUnit "Frequency", "GHz"',
                        '.MaterialUnit "Geometry", "mm"',
                        '.MaterialUnit "Time", "s"',
                        '.MaterialUnit "Temperature", "Kelvin"',
                        '.Mu "1.0"',
                        '.Sigma "4.561e+007"',
                        '.Rho "19320.0"',
                        '.ThermalType "Normal"',
                        '.ThermalConductivity "314.0"',
                        '.SpecificHeat "130", "J/K/kg"',
                        '.MetabolicRate "0"',
                        '.BloodFlow "0"',
                        '.VoxelConvection "0"',
                        '.MechanicsType "Isotropic"',
                        '.YoungsModulus "78"',
                        '.PoissonsRatio "0.42"',
                        '.ThermalExpansionRate "14"',
                        '.ReferenceCoordSystem "Global"',
                        '.CoordSystemType "Cartesian"',
                        '.NLAnisotropy "False"',
                        '.NLAStackingFactor "1"',
                        '.NLADirectionX "1"',
                        '.NLADirectionY "0"',
                        '.NLADirectionZ "0"',
                        '.Colour "1", "1", "0"',
                        '.Wireframe "False"',
                        '.Reflection "False"',
                        '.Allowoutline "True"',
                        '.Transparentoutline "False"',
                        '.Transparency "0"',
                        '.Create',
                       'End With' ]
            sCommand = line_break.join(sCommand)
            self.modeler.add_to_history('define gold', sCommand)