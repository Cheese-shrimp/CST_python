from typing import Union
import pandas as pd
import re
import os
# ==============================参数========================================
class Set_parameter:
    '''
    This class is used to add,delete,modify parameters,and so on.
        add_parameter : add parameter.
        delete_parameter : delete parameter.
        modify_parameter : modify parameter.
    '''
    def __init__(self,modeler):
        self.modeler = modeler;
    def add_param(self,name:str,value: Union[int, float]):
        """
        This method is used to add parameter.

        Args:
            name (str) : name of parameter.\n
            value (Union[int, float]) : value of parameter.
        """
        self.modeler.add_to_history('StoreParameter','MakeSureParameterExists("%s","%f")' % (name,value))
    def del_param(self,name:str):
        """
        This method is used to delete parameter.

        Args:
            name (str) : name of parameter.
        """
        self.modeler.add_to_history('StoreParameter','DeleteParameter"%s"' % name)
    def mod_param_value(self,name,new_value:Union[int, float]):
        '''
        This method is used to change the parameter to another value.

        Args:
            name (str): name of parameter.\n
            new_value (Union[int, float]) : value of parameter.
        '''
        self.modeler.add_to_history('StoreParameter','DeleteParameter"%s"' % name)
        self.modeler.add_to_history('StoreParameter','MakeSureParameterExists("%s","%f")' % (name,new_value))
    def mod_param_name(self,old_name:str,new_name:str):
        '''
        This method is used to change the name of parameter.

        Args:
            old_name (str): old name of parameter.\n
            new_name (str) : new name of parameter.
        '''
        self.modele.add_to_history('StoreParameter','RenameParameter("%s","%s")' % (old_name,new_name))
    def imp_param(self,file_path=None):
        '''
        This method is used to import the csv parameter file.

        CSV file demonstration:

                    value
            w1      16.0\n
            w2       2.0\n
            t1      10.0\n
            t2       0.2\n
        '''
        if file_path is None:
            raise ValueError('未指定文件路径！')
        else:
            df = pd.read_csv(file_path)
            df.columns = ["parameters","values"]
            records = df.to_dict(orient='records')
            # 将每个字典中的键值对转换为元组
            result = [(d['parameters'], d['values']) for d in records]
            # print(result)
            for name,value in result:
                self.modeler.add_to_history('StoreParameter','MakeSureParameterExists("%s","%f")' % (name,value))
    def out_param(self,file_path=None,output_path=None):
        '''
        This method is used to export .txt parameters from the cst to a csv file.

        txt to csv.
        ''' 
        if file_path is None:
            raise ValueError('未指定文件路径！')
        else:
            # 读取文本文件并保持文本数据在 text 中
            with open(file_path, 'r') as f:
                text = f.read()
            # 定义正则表达式模式
            pattern = r'(\w+)="([\d\.]+)"'
            # 提取所有参数的值并将它们转换为字典
            params = dict(re.findall(pattern, text))
            # 将字典转换为 DataFrame
            df = pd.DataFrame([params])
            # 将列值从字符串转换为浮点数
            df = df.astype(float)
            df = df.T
            # 输出结果
            df.columns = ["value"]
            # print(df)
            if output_path is None:
                path = os.getcwd()#获取当前py文件所在文件夹
                filename_parameter = 'output_parameter.csv'
                fullname = os.path.join(path,filename_parameter)
                df.to_csv(fullname)
            else:
                filename_parameter = 'output_parameter.csv'
                fullname = os.path.join(output_path,filename_parameter)
                df.to_csv(fullname)

# ==============================基础设置========================================
class Basic:
    '''
    This class is uesd for basic setup of cst.
        init_cst : Global unit initialization 
    '''
    def __init__(self,modeler):
        self.modeler = modeler
    def bs_set(self,Unit:str,Frequency:str,Fre_start:Union[int, float],Fre_stop:Union[int, float],Time:str):
        """
        This method is used to set unit,frequency,begining and end of frequency,time,and so on.

        Args:
            Unit : {"cm","mm","um","nm"}\n
            Frequency : {"Hz","kHz","MHz","GHz","THz","PHz"}\n
            Time:{"fs","ps","ns","us","ms","s"}\n
        """
        line_break = '\n'#换行
        #全局单位初始化
        sCommand = ['With Units',
                    '.Geometry "%s"'%Unit,
                    '.Frequency "%s"'%Frequency,
                    '.Time "%s"'%Time,
                    'End With']
        sCommand = line_break.join(sCommand)
        self.modeler.add_to_history('define units', sCommand)
        #全局单位初始化结束
        #工作频率设置
        sCommand = 'Solver.FrequencyRange "%f","%f"'  % (Fre_start,Fre_stop)#0-2Thz
        self.modeler.add_to_history('define frequency range', sCommand)
        self.modeler.add_to_history('ChangeSolverType', 'ChangeSolverType "HF Frequency Domain"')
    def init_metasurface(self):
        line_break = '\n'
        sCommand = ['With Units',
                '.Geometry "um"',
                '.Frequency "THz"',
                '.Voltage "V"',
                '.Resistance "Ohm"',
                '.Inductance "H"',
                '.TemperatureUnit  "Kelvin"',
                '.Time "ns"',
                '.Current "A"',
                '.Conductance "Siemens"',
                '.Capacitance "F"',
                'End With']
        sCommand = line_break.join(sCommand)
        self.modeler.add_to_history('Units', sCommand)

        sCommand = ['With Background',
                '.Type "Normal"',
                '.Epsilon "1.0"',
                '.Mu "1.0"',
                '.Rho "1.204"',
                '.ThermalType "Normal"',
                '.ThermalConductivity "0.026"',
                '.HeatCapacity "1.005"',
                '.XminSpace "0.0"',
                '.XmaxSpace "0.0"',
                '.YminSpace "0.0"',
                '.YmaxSpace "0.0"',
                '.ZminSpace "60.0"',#z轴60
                '.ZmaxSpace "60.0"',#z轴60
                 'End With']       
        sCommand = line_break.join(sCommand)
        self.modeler.add_to_history('Background', sCommand)

        sCommand = ['With FloquetPort',
                '.Reset',
                '.SetDialogTheta "0"',
                '.SetDialogPhi "0"',
                '.SetSortCode "+beta/pw"',
                '.SetCustomizedListFlag "False"',
                '.Port "Zmin"',
                '.SetNumberOfModesConsidered "2"',
                '.SetDistanceToReferencePlane "-60" ',#z轴-60
                '.SetUseCircularPolarization "False" ',
                '.Port "Zmax"',
                '.SetNumberOfModesConsidered "2"',
                '.SetDistanceToReferencePlane "-60" ',#z轴-60
                '.SetUseCircularPolarization "False" ',
                'End With']       
        sCommand = line_break.join(sCommand)
        self.modeler.add_to_history('FloquetPort', sCommand)

        sCommand = ['MakeSureParameterExists "theta", "0"',
                    'SetParameterDescription "theta", "spherical angle of incident plane wave"',
                    'MakeSureParameterExists "phi", "0"',
                   ' SetParameterDescription "phi", "spherical angle of incident plane wave"']       
        sCommand = line_break.join(sCommand)
        self.modeler.add_to_history('init1', sCommand)

        sCommand = ['With Boundary',
                '.Xmin "unit cell"',
                '.Xmax "unit cell"',
                '.Ymin "unit cell"',
                '.Ymax "unit cell"',
                '.Zmin "open"',
                '.Zmax "open"',
                '.Xsymmetry "none"',
                '.Ysymmetry "none"',
                '.Zsymmetry "none"',
                '.XPeriodicShift "0.0"',
                '.YPeriodicShift "0.0"',
                '.ZPeriodicShift "0.0"',
                '.PeriodicUseConstantAngles "False"',
                '.SetPeriodicBoundaryAngles "theta", "phi"',
                '.SetPeriodicBoundaryAnglesDirection "inward"',
                '.UnitCellFitToBoundingBox "True"',
                '.UnitCellDs1 "0.0"',
                '.UnitCellDs2 "0.0"',
                '.UnitCellAngle "90.0"',
                'End With']       
        sCommand = line_break.join(sCommand)
        self.modeler.add_to_history('Boundary', sCommand)

        sCommand = ['With Mesh',
                '.MeshType "Tetrahedral"',
                'End With']       
        sCommand = line_break.join(sCommand)
        self.modeler.add_to_history('Mesh', sCommand)

        sCommand = ['With FDSolver',
                '.Reset',
                '.Stimulation "List", "List"',
                '.ResetExcitationList',
                '.AddToExcitationList "Zmax", "TE(0,0);TM(0,0)"',
                '.LowFrequencyStabilization "False"',
                'End With']         
        sCommand = line_break.join(sCommand)
        self.modeler.add_to_history('FDSolver', sCommand)

        sCommand = ['With MeshSettings',
                '.SetMeshType "Tet"',
                '.Set "Version", 1%',
                'End With']         
        sCommand = line_break.join(sCommand)
        self.modeler.add_to_history('MeshSettings', sCommand)

        sCommand = ['With Mesh',
                '.MeshType "Tetrahedral"',
                'End With']         
        sCommand = line_break.join(sCommand)
        self.modeler.add_to_history('Mesh', sCommand)

        self.modeler.add_to_history('init2', 'ChangeSolverType("HF Frequency Domain")')
    def background(self,Zmin,Zmax):
        line_break = '\n'
        sCommand = ['With FloquetPort',
                '.Reset',
                '.SetDialogTheta "0"',
                '.SetDialogPhi "0"',
                '.SetSortCode "+beta/pw"',
                '.SetCustomizedListFlag "False"',
                '.Port "Zmin"',
                '.SetNumberOfModesConsidered "2"',
                '.SetDistanceToReferencePlane "%d" '%Zmin,#z轴-60
                '.SetUseCircularPolarization "False" ',
                '.Port "Zmax"',
                '.SetNumberOfModesConsidered "2"',
                '.SetDistanceToReferencePlane "%d" '%Zmax,#z轴-60
                '.SetUseCircularPolarization "False" ',
                'End With']       
        sCommand = line_break.join(sCommand)
        self.modeler.add_to_history('FloquetPort', sCommand)

    def background(self,Fre_start,Fre_stop):
        line_break = '\n'
        Fre_center = (Fre_start + Fre_stop)/2
        lambda_cst = 3000000000 / Fre_center * 1000000000000
        querter_lambda = lambda_cst / 4
        sCommand = ['With Background',
                '.Type "Normal"',
                '.Epsilon "1.0"',
                '.Mu "1.0"',
                '.Rho "1.204"',
                '.ThermalType "Normal"',
                '.ThermalConductivity "0.026"',
                '.HeatCapacity "1.005"',
                '.XminSpace "0.0"',
                '.XmaxSpace "0.0"',
                '.YminSpace "0.0"',
                '.YmaxSpace "0.0"',
                '.ZminSpace "%f"'%querter_lambda,
                '.ZmaxSpace "%f"'%querter_lambda,
                 'End With']       
        sCommand = line_break.join(sCommand)
        self.modeler.add_to_history('init', sCommand)

    def solve_num(self,num):
        line_break = '\n'
        sCommand = ['With FDSolver',
                '.Reset ',
                '.SetMethod "Tetrahedral", "General purpose"', 
                '.SetNumberOfResultDataSamples "%d"'%num,      
                'End With']       
        sCommand = line_break.join(sCommand)
        self.modeler.add_to_history('solve_num', sCommand)

    def start_sim(self):
        line_break = '\n'
        self.modeler.add_to_history('MeshSetCreator','Mesh.SetCreator "High Frequency" ')
        sCommand = ['With FDSolver',
                    '.Reset' ,
                    '.SetMethod "Tetrahedral", "General purpose"' ,
                    '.OrderTet "Second"' ,
                    '.OrderSrf "First" ',
                    '.Stimulation "Zmax", "All" ',
                    '.ResetExcitationList' ,
                    '.AutoNormImpedance "False" ',
                    '.NormingImpedance "50" ',
                    '.ModesOnly "False" ',
                    '.ConsiderPortLossesTet "True" ',
                    '.SetShieldAllPorts "False" ',
                    '.AccuracyHex "1e-6" ',
                    '.AccuracyTet "1e-4" ',
                    '.AccuracySrf "1e-3" ',
                    '.LimitIterations "False"' ,
                    '.MaxIterations "0"' ,
                    '.SetCalcBlockExcitationsInParallel "True", "True", "" ',
                    '.StoreAllResults "False" ',
                    '.StoreResultsInCache "False"' ,
                    '.UseHelmholtzEquation "True" ',
                    '.LowFrequencyStabilization "True" ',
                    '.Type "Auto" ',
                    '.MeshAdaptionHex "False" ',
                    '.MeshAdaptionTet "True"' ,
                    '.AcceleratedRestart "True"' ,
                    '.FreqDistAdaptMode "Distributed"' ,
                    '.NewIterativeSolver "True"' ,
                    '.TDCompatibleMaterials "False"' ,
                    '.ExtrudeOpenBC "False"' ,
                    '.SetOpenBCTypeHex "Default"' ,
                    '.SetOpenBCTypeTet "Default"' ,
                    '.AddMonitorSamples "True"' ,
                    '.CalcPowerLoss "True"' ,
                    '.CalcPowerLossPerComponent "False"' ,
                    '.StoreSolutionCoefficients "True"' ,
                    '.UseDoublePrecision "False"' ,
                    '.UseDoublePrecision_ML "True"' ,
                    '.MixedOrderSrf "False"' ,
                    '.MixedOrderTet "False"' ,
                    '.PreconditionerAccuracyIntEq "0.15"' ,
                    '.MLFMMAccuracy "Default"' ,
                    '.MinMLFMMBoxSize "0.3"' ,
                    '.UseCFIEForCPECIntEq "True"' ,
                    '.UseFastRCSSweepIntEq "false"' ,
                    '.UseSensitivityAnalysis "False"' ,
                    '.RemoveAllStopCriteria "Hex"',
                    '.AddStopCriterion "All S-Parameters", "0.01", "2", "Hex", "True"',
                    '.AddStopCriterion "Reflection S-Parameters", "0.01", "2", "Hex", "False"',
                    '.AddStopCriterion "Transmission S-Parameters", "0.01", "2", "Hex", "False"',
                    '.RemoveAllStopCriteria "Tet"',
                    '.AddStopCriterion "All S-Parameters", "0.01", "2", "Tet", "True"',
                    '.AddStopCriterion "Reflection S-Parameters", "0.01", "2", "Tet", "False"',
                    '.AddStopCriterion "Transmission S-Parameters", "0.01", "2", "Tet", "False"',
                    '.AddStopCriterion "All Probes", "0.05", "2", "Tet", "True"',
                    '.RemoveAllStopCriteria "Srf"',
                    '.AddStopCriterion "All S-Parameters", "0.01", "2", "Srf", "True"',
                    '.AddStopCriterion "Reflection S-Parameters", "0.01", "2", "Srf", "False"',
                    '.AddStopCriterion "Transmission S-Parameters", "0.01", "2", "Srf", "False"',
                    '.SweepMinimumSamples "3" ',
                    '.SetNumberOfResultDataSamples "500" ',
                    '.SetResultDataSamplingMode "Automatic"' ,
                    '.SweepWeightEvanescent "1.0" ',
                    '.AccuracyROM "1e-4" ',
                    '.AddSampleInterval "", "", "1", "Automatic", "True" ',
                    '.AddSampleInterval "", "", "", "Automatic", "False"' ,
                    '.MPIParallelization "False"',
                    '.UseDistributedComputing "False"',
                    '.NetworkComputingStrategy "RunRemote"',
                    '.NetworkComputingJobCount "3"',
                    '.UseParallelization "True"',
                    '.MaxCPUs "128"',
                    '.MaximumNumberOfCPUDevices "2"',
                'End With']       
        sCommand = line_break.join(sCommand)
        self.modeler.add_to_history('FDSolver', sCommand)
        sCommand = ['With IESolver',
                    '.Reset ',
                    '.UseFastFrequencySweep "True"' ,
                    '.UseIEGroundPlane "False"' ,
                    '.SetRealGroundMaterialName ""' ,
                    '.CalcFarFieldInRealGround "False"' ,
                    '.RealGroundModelType "Auto" ',
                    '.PreconditionerType "Auto"' ,
                    '.ExtendThinWireModelByWireNubs "False"' ,
                'End With']   
        sCommand = line_break.join(sCommand)
        self.modeler.add_to_history('IESolver', sCommand)        
        sCommand = ['With IESolver',
                    '.SetFMMFFCalcStopLevel "0" ',
                    '.SetFMMFFCalcNumInterpPoints "6"' ,
                    '.UseFMMFarfieldCalc "True" ',
                    '.SetCFIEAlpha "0.500000"' ,
                    '.LowFrequencyStabilization "False"' ,
                    '.LowFrequencyStabilizationML "True"' ,
                    '.Multilayer "False"' ,
                    '.SetiMoMACC_I "0.0001"' ,
                    '.SetiMoMACC_M "0.0001"' ,
                    '.DeembedExternalPorts "True"' ,
                    '.SetOpenBC_XY "True"' ,
                    '.OldRCSSweepDefintion "False"' ,
                    '.SetRCSOptimizationProperties "True", "100", "0.00001"' ,
                    '.SetAccuracySetting "Custom"' ,
                    '.CalculateSParaforFieldsources "True" ',
                    '.ModeTrackingCMA "True"' ,
                    '.NumberOfModesCMA "3"' ,
                    '.StartFrequencyCMA "-1.0"' ,
                    '.SetAccuracySettingCMA "Default"' ,
                    '.FrequencySamplesCMA "0"' ,
                    '.SetMemSettingCMA "Auto"' ,
                    '.CalculateModalWeightingCoefficientsCMA "True"' ,
                'End With']   
        sCommand = line_break.join(sCommand)
        self.modeler.add_to_history('IESolver2', sCommand)  


class Document:
    '''
    This class is uesd to governing document
    '''
    def __init__(self,modeler) -> None:
        self.modeler = modeler
    def exdata(self,sp:str,type:str,format:str,path:str,name:str):
        '''
        This method is uesd to export sim data

        Args:
            sp(str):SZmax(1),Zmax(1)\n
            type(str):mag,dB,real,imag,phase
            format(str):txt,csv
        '''
        line_break = '\n'
        tree = "1D Results\\S-Parameters\\" + sp
        if type == "mag":
            sCommand=['SelectTreeItem ("%s")'%tree,
                'With Plot1D',
                '.PlotView "magnitude"',
                '.Plot',
                'End With',]
            sCommand = line_break.join(sCommand)
            self.modeler.add_to_history('mag', sCommand)
        elif type == "dB":
            sCommand=['SelectTreeItem ("%s")'%tree,
                'With Plot1D',
                '.PlotView "magnitudedb"',
                '.Plot',
                'End With',]
            sCommand = line_break.join(sCommand)
            self.modeler.add_to_history('dB', sCommand)
        elif type == "real":
            sCommand=['SelectTreeItem ("%s")'%tree,
                'With Plot1D',
                '.PlotView "real"',
                '.Plot',
                'End With',]
            sCommand = line_break.join(sCommand)
            self.modeler.add_to_history('real', sCommand)
        elif type == "imag":
            sCommand=['SelectTreeItem ("%s")'%tree,
                'With Plot1D',
                '.PlotView "imaginary"',
                '.Plot',
                'End With',]
            sCommand = line_break.join(sCommand)
            self.modeler.add_to_history('imag', sCommand)
        elif type == "phase":
            sCommand=['SelectTreeItem ("%s")'%tree,
                'With Plot1D',
                '.PlotView "phase"',
                '.Plot',
                'End With',]
            sCommand = line_break.join(sCommand)
            self.modeler.add_to_history('phase', sCommand)
        else:
            print("请输入mag/dB/real/imag/phase")
        
        if format == "txt":
            line_break = '\n'
            filename = name + '.txt'
            fullname = os.path.join(path,filename)
            fixed_str = fullname.replace('\\', '//')  # 将 '\' 替换为 '//'
            print('输出文件地址为：' + fullname)  # 输出结果
            sCommand = ['SelectTreeItem ("%s")'%tree,
                'With ASCIIExport',
                '.Reset',
                '.SetfileType "csv"',
                '.FileName ("%s")'%fixed_str,
                '.Execute',
                'End With']
            sCommand = line_break.join(sCommand)
            self.modeler.add_to_history('init', sCommand)
            
        elif format == "csv":
            line_break = '\n'
            filename = name + '.csv'
            fullname = os.path.join(path,filename)
            fixed_str = fullname.replace('\\', '//')  # 将 '\' 替换为 '//'
            print('输出文件地址为：' + fullname)  # 输出结果
            sCommand=['SelectTreeItem ("%s")'%tree,
                'With ASCIIExport',
                '.Reset',
                '.SetfileType "csv"',
                '.FileName ("%s")'%fixed_str,
                '.Execute',
                'End With']
            sCommand = line_break.join(sCommand)
            self.modeler.add_to_history('init', sCommand)
        else:
            print("请输入txt/csv")



class Shape:
    '''
    
    '''
    def __init__(self,modeler) -> None:
        self.modeler = modeler
    def brick(self,name,component,material,xrange,yrange,zrange):
        line_break = '\n'#换行
        xmin, xmax = xrange
        ymin, ymax = yrange
        zmin, zmax = zrange
        sCommand = ['With Brick',
                '.Reset',
                '.Name "%s" '%name,
                '.Component "%s" '%component,
                '.Material "%s"'%material ,
                '.Xrange "%s", "%s"' %(xmin,xmax),
                '.Yrange "%s", "%s"'%(ymin,ymax) ,
                '.Zrange "%s", "%s"'%(zmin,zmax) ,
                '.Create',
                'End With'] 
        sCommand = line_break.join(sCommand)
        self.modeler.add_to_history('Brick', sCommand)

    def cylinder(self,name,component,material,ro,ri,zrange):
        line_break = '\n'#换行
        zmin, zmax = zrange
        sCommand = ['With Cylinder ',
                '.Reset',
                '.Name "%s" '%name,
                '.Component "%s"'%component,
                '.Material "%s"'%material ,
                '.OuterRadius "%s"'%ro ,
                '.InnerRadius "%s"'%ri ,
                '.Axis "z"' ,
                '.Zrange "%s", "%s"'%(zmin,zmax) ,
                '.Xcenter "0"' ,
                '.Ycenter "0"' ,
                '.Segments "0"' ,
                '.Create',
                'End With'] 
        sCommand = line_break.join(sCommand)
        self.modeler.add_to_history('cylinder', sCommand)

    # 不对称开口环

    def ASR(self,name,component,material,router,rinner,zrange,angleu,anglel):
        line_break = '\n'#换行
        zmin, zmax = zrange
        sCommand = ['With Cylinder',
                '.Reset',
                '.Name "%s" '%name,
                '.Component "%s"'%component,
                '.Material "%s"'%material ,
                '.OuterRadius "%s"'%router ,
                '.InnerRadius "%s"'%rinner ,
                '.Axis "z"' ,
                '.Zrange "%s", "%s"'%(zmin,zmax) ,
                '.Xcenter "0"' ,
                '.Ycenter "0"' ,
                '.Segments "0"' ,
                '.Create',
                'End With'] 
        sCommand = line_break.join(sCommand)
        self.modeler.add_to_history('Brick', sCommand)
        #yz坐标系
        sCommand = ['With WCS',
                '.SetNormal "1", "0", "0"',
                '.SetUVector "0", "1", "0"',
                '.ActivateWCS "local" ',
                'End With']
        sCommand = line_break.join(sCommand)
        self.modeler.add_to_history('yz_WCS',sCommand)
        #旋转上开口角1
        self.modeler.add_to_history('rotatev','WCS.RotateWCS "v", "%s/2" '%angleu)
        #切第一次
        self.modeler.add_to_history('shape_slice','Solid.SliceComponent "%s" '%component)
        #旋转上开口角2
        self.modeler.add_to_history('rotatev','WCS.RotateWCS "v", "-%s" '%angleu)
        #切第二次
        self.modeler.add_to_history('shape_slice','Solid.SliceComponent "%s" '%component)
        if angleu != anglel :
            #恢复到yz坐标系，准备第二开口
            sCommand = ['With WCS',
                    '.SetNormal "1", "0", "0"',
                    '.SetUVector "0", "1", "0"',
                    '.ActivateWCS "local" ',
                    'End With']
            sCommand = line_break.join(sCommand)
            self.modeler.add_to_history('yz_WCS',sCommand)
            #旋转下开口角1
            self.modeler.add_to_history('rotatev','WCS.RotateWCS "v", "%s/2" '%anglel)
            #切第一次
            self.modeler.add_to_history('shape_slice','Solid.SliceComponent "%s" '%component)
            #旋转下开口角2
            self.modeler.add_to_history('rotatev','WCS.RotateWCS "v", "-%s" '%anglel)
            #切第二次
            self.modeler.add_to_history('shape_slice','Solid.SliceComponent "%s" '%component)
            if angleu > anglel:
                #删除多余
                self.modeler.add_to_history('d1','Solid.Delete "%s:%s"'%(component,name))
                self.modeler.add_to_history('d2','Solid.Delete "%s:%s_1"'%(component,name))
                self.modeler.add_to_history('d3','Solid.Delete "%s:%s_1_1"'%(component,name))
                self.modeler.add_to_history('d4','Solid.Delete "%s:%s_1_2_1"'%(component,name))

                #合并
                sCommand = ['Solid.Add ("%s:%s_2", "%s:%s_2_1") '%(component,name,component,name),
                            'Solid.Add ("%s:%s_2", "%s:%s_2_2") '%(component,name,component,name)]
                sCommand = line_break.join(sCommand)
                self.modeler.add_to_history('Add', sCommand)
            elif angleu < anglel :
                #删除多余
                self.modeler.add_to_history('d1','Solid.Delete "%s:%s"'%(component,name))
                self.modeler.add_to_history('d2','Solid.Delete "%s:%s_1_1"'%(component,name))
                self.modeler.add_to_history('d3','Solid.Delete "%s:%s_1_1_1_1"'%(component,name))
                self.modeler.add_to_history('d4','Solid.Delete "%s:%s_4"'%(component,name))
                #合并
                sCommand = ['Solid.Add ("%s:%s_1", "%s:%s_1_1_1") '%(component,name,component,name),
                            'Solid.Add ("%s:%s_1", "%s:%s_3") '%(component,name,component,name)]
                sCommand = line_break.join(sCommand)
                self.modeler.add_to_history('Add', sCommand)
            
        elif angleu == anglel:
            #删除多余
            self.modeler.add_to_history('d1','Solid.Delete "%s:%s"'%(component,name))
            self.modeler.add_to_history('d2','Solid.Delete "%s:%s_1_1"'%(component,name))

        self.modeler.add_to_history('global_WCS','WCS.AlignWCSWithGlobalCoordinates')


    def subtract(self,object_to,object_be) -> None:
        component1,name1 = object_to
        component2,name2 = object_be
        line_break = '\n'
        sCommand = ['Solid.Subtract ("%s:%s", "%s:%s") '%(component1,name1,component2,name2)]
        sCommand = line_break.join(sCommand)
        self.modeler.add_to_history('subtract', sCommand)

    def add(self,object_to,object_be) -> None:
        component1,name1 = object_to
        component2,name2 = object_be
        line_break = '\n'
        sCommand = ['Solid.Add ("%s:%s", "%s:%s") '%(component1,name1,component2,name2)]
        sCommand = line_break.join(sCommand)
        self.modeler.add_to_history('Add', sCommand)

    def delete_shape(self,component,name) -> None:
        line_break = '\n'
        sCommand = ['Solid.Delete "%s:%s" '%(component,name)]
        sCommand = line_break.join(sCommand)
        self.modeler.add_to_history('Delete', sCommand)

    def delete_com(self,component) -> None:
        line_break = '\n'
        sCommand = ['Component.Delete "%s" '%component]
        sCommand = line_break.join(sCommand)
        self.modeler.add_to_history('ComponentDelete', sCommand)

    def shape_slice(self,component) -> None:
        self.modeler.add_to_history('shape_slice','Solid.SliceComponent "%s" '%component)
class WCS:
    '''
    
    '''
    def __init__(self,modeler) -> None:
        self.modeler = modeler
    def wcs_face(self,component:str,name:str,faceid:int) -> None:
        line_break = '\n'
        sCommand = ['Pick.PickFaceFromId("%s:%s", "%d" )'%(component,name,faceid),'WCS.AlignWCSWithSelected "Face"']
        sCommand = line_break.join(sCommand)
        self.modeler.add_to_history('wcs_face', sCommand)
    def wcs_global(self) -> None:
        self.modeler.add_to_history('global_WCS','WCS.ActivateWCS "global"')
    def wcs_move(self,u,v,w) -> None:
        self.modeler.add_to_history('move_WCS','WCS.MoveWCS "local", "%s", "%s", "%s"'%(u,v,w))
    def wcs_yz(self) -> None:
        line_break = '\n'
        sCommand = ['With WCS',
                '.SetNormal "1", "0", "0"',
                '.SetUVector "0", "1", "0"',
                '.ActivateWCS "local" ',
                'End With']
        sCommand = line_break.join(sCommand)
        self.modeler.add_to_history('yz_WCS',sCommand)
    def wcs_rotatev(self,angle) -> None:
        self.modeler.add_to_history('rotatev','WCS.RotateWCS "v", "%s" '%angle)