import sys
import os
import re
import time

# user_input = input("请输入cst库地址(如E:\\CST Studio Suite 2020\\AMD64\\python_cst_libraries)：")
# if '%s'%user_input not in sys.path:
#     sys.path.append('%s'%user_input)
# sys.path = list(set(sys.path))
# print(sys.path)

# def import_from_previous():
#     '''检查上次导入的地址是否存在'''

#     if os.path.exists('previous_import.txt'):
#         with open('previous_import.txt', 'r') as file:
#             previous_import = file.read()
#             answer = input('是否使用上次导入的地址 ' + previous_import + ' ? (y/n): ')
#             if answer.lower() == 'y':
#                 return previous_import

#     return None

def import_from_previous():
    '''检查上次导入的地址是否存在'''

    if os.path.exists('previous_import.txt'):
        with open('previous_import.txt', 'r') as file:
            previous_import = file.read()
            answer = input('是否使用上次导入的地址 ' + previous_import + ' ? (y/n): ')

            # 检查用户输入是否有效
            while answer.lower() not in ['y', 'n']:
                time.sleep(10)  # 等待十秒钟
                answer = input('是否使用上次导入的地址 ' + previous_import + ' ? (y/n): ')

            if answer.lower() == 'y':
                return previous_import

    return None

def save_previous_import(address):
    '''保存最后一次导入的地址'''

    with open('previous_import.txt', 'w') as file:
        file.write(address)

def get_import_address():
    '''返回导入地址'''

    previous_import = import_from_previous()
    if previous_import:
        return previous_import

    address = input('请输入cst库地址(如E:\\CST Studio Suite 2020\\AMD64\\python_cst_libraries)：')
    save_previous_import(address)
    return address

# 在这里执行相关代码
address = get_import_address()
# 这里可以插入您需要导入的代码


if '%s'%address not in sys.path:
    sys.path.append('%s'%address)
sys.path = list(set(sys.path))
print(30*"=" + "仿真开始" + 30*"=")