# ==============================后处理========================================
import pandas as pd
import os
from functools import reduce
class Cal:
    def __init__(self) -> None:
        pass
    def switch_cst(self,path):
        df = pd.read_csv(path, header=None,)
        data = pd.DataFrame(df.iloc[2:,0]).reset_index(drop=True)
        data = data.to_numpy()
        store = []
        for i in range(len(data)):
            str = data[i].item()
            str_list = str.split()
            store.append(str_list)
        data = pd.DataFrame(store)
        return data.apply(pd.to_numeric)

    def splicing_txt(self,folder_path):

        # folder_path = r"C:\Users\Administrator\Desktop\CST Simulation file\CST_data"
        df = pd.DataFrame()

        for i, filename in enumerate(os.listdir(folder_path)):
            file_path = os.path.join(folder_path, filename)
            print(filename)
            print(file_path)
            if os.path.isfile(file_path):
                # 如果是第一个文件，则读取所有列
                if i == 0:
                    file_df = self.switch_cst(file_path)
                # 否则，只读取第二列
                else:
                    file_df = self.switch_cst(file_path)
                    file_df = file_df[1]
                # 将当前文件的数据添加到 df 中
                df = pd.concat([df, file_df], axis=1, ignore_index=True)
        return df

    def merged_txt(self,folder_path):
            # 获取文件夹内所有文件
        file_list = [f for f in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, f))]
        file_list_sorted = sorted(file_list, key=lambda x: int(os.path.splitext(x)[0]))  # 按文件名称的数字部分进行排序

        # 读取每个文本文件并转换为DataFrame对象
        dataframes = []
        for i, file_name in enumerate(file_list_sorted):
            if file_name.endswith(".txt"):
                file_path = os.path.join(folder_path, file_name)
                df = self.switch_cst(file_path)  # 使用适当的分隔符和其他参数来读取文本文件
                dataframes.append(df)
                globals()[f"df{i+1}"] = df  # 将每个DataFrame对象命名为df1、df2、df3...

        # 输出文件数量
        print(f"文件数量为：{len(file_list)}")
        tables = []
        for i in range(0, len(file_list)):
            var_name = "df%d" % (i + 1)
            tables.append(globals()[var_name])

        # 使用reduce函数合并表格
        merged_df = reduce(lambda left, right: pd.merge(left, right, on=0), tables)
        column_names = merged_df.columns.tolist()
        # 重命名第一列为"Fre"
        column_names[0] = "Fre"
        # 重命名其余列为"Sim1"，"Sim2"，等等
        for i in range(1, len(column_names)):
            column_names[i] = "Sim" + str(i)
        # 更新DataFrame的列名
        merged_df.columns = column_names
        return merged_df 